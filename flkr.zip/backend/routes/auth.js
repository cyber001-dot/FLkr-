/**
 * routes/auth.js — Admin auth flow.
 *
 * Flow:
 *   1. POST /auth/login         -> validates password; if OK, issues OTP
 *   2. POST /auth/otp/verify    -> verifies OTP, returns JWT
 *
 * Lockout: 3 failed login attempts within the lockout window -> 60s cooldown.
 * Every attempt is recorded in login_attempts and audit_log.
 */
const express = require('express');
const { db, hashSecret, ADMIN_EMAIL } = require('../db');
const { validate, loginSchema, otpVerifySchema } = require('../middleware/validate');
const { makeLimiter } = require('../middleware/rateLimit');
const { issueOtp, verifyOtp } = require('../utils/otp');
const { sendOtp } = require('../utils/email');
const { sign } = require('../utils/jwt');
const logger = require('../utils/logger');

const router = express.Router();

const LOCKOUT_THRESHOLD = Number(process.env.LOCKOUT_THRESHOLD || 3);
const LOCKOUT_DURATION_MS = Number(process.env.LOCKOUT_DURATION_MS || 60_000);

// Per-IP rate limit on login + OTP endpoints.
const loginLimiter = makeLimiter({
  windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS || 60_000),
  max: Number(process.env.LOGIN_RATE_LIMIT_MAX || 5),
  routeKey: 'auth:login',
});

const otpLimiter = makeLimiter({
  windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS || 60_000),
  max: Number(process.env.OTP_RATE_LIMIT_MAX || 5),
  routeKey: 'auth:otp',
});

function recentFailures(ip, email) {
  const since = Math.floor((Date.now() - LOCKOUT_DURATION_MS) / 1000);
  const byIp = db.prepare(
    `SELECT COUNT(*) AS n FROM login_attempts
     WHERE ip = ? AND success = 0 AND created_at >= ?`
  ).get(ip, since);
  if (byIp.n >= LOCKOUT_THRESHOLD) {
    return { locked: true, by: 'ip', count: byIp.n };
  }
  if (email) {
    const byEmail = db.prepare(
      `SELECT COUNT(*) AS n FROM login_attempts
       WHERE email = ? AND success = 0 AND created_at >= ?`
    ).get(email, since);
    if (byEmail.n >= LOCKOUT_THRESHOLD) {
      return { locked: true, by: 'email', count: byEmail.n };
    }
  }
  return { locked: false };
}

function recordAttempt(ip, email, success, reason) {
  db.prepare(
    `INSERT INTO login_attempts (ip, email, success, reason) VALUES (?, ?, ?, ?)`
  ).run(ip, email || null, success ? 1 : 0, reason || null);
}

/**
 * POST /auth/login
 * Body: { email, password }
 * Returns: 200 { otp_required: true } | 401 | 423 (locked)
 */
router.post('/login', loginLimiter, validate({ body: loginSchema }), async (req, res) => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const { email, password } = req.body;

  // Restrict to the configured admin email.
  if (email.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
    recordAttempt(ip, email, false, 'unknown_email');
    logger.warn(ip, 'login_unknown_email', { email });
    return res.status(401).json({ error: 'invalid_credentials' });
  }

  const lock = recentFailures(ip, email);
  if (lock.locked) {
    logger.warn(ip, 'login_locked', { by: lock.by, count: lock.count });
    return res.status(423).json({
      error: 'locked',
      retryAfter: Math.ceil(LOCKOUT_DURATION_MS / 1000),
    });
  }

  const admin = db.prepare('SELECT pass_hash FROM admins WHERE email = ?').get(email);
  if (!admin || admin.pass_hash !== hashSecret(password)) {
    recordAttempt(ip, email, false, 'bad_password');
    logger.warn(ip, 'login_bad_password', { email });
    const failCount = recentFailures(ip, email);
    if (failCount.locked) {
      return res.status(423).json({
        error: 'locked',
        retryAfter: Math.ceil(LOCKOUT_DURATION_MS / 1000),
      });
    }
    return res.status(401).json({ error: 'invalid_credentials' });
  }

  // Password OK — issue OTP.
  try {
    const { code, expiresAt } = issueOtp(email);
    await sendOtp(email, code);
    recordAttempt(ip, email, true, 'password_ok_otp_sent');
    logger.info(email, 'login_otp_issued', { expiresAt });
    return res.json({ otp_required: true, expiresAt });
  } catch (err) {
    logger.error(email, 'login_otp_failed', { error: err.message });
    return res.status(500).json({ error: 'otp_send_failed' });
  }
});

/**
 * POST /auth/otp/verify
 * Body: { email, code }
 * Returns: 200 { token, expiresAt } | 401
 */
router.post('/otp/verify', otpLimiter, validate({ body: otpVerifySchema }), (req, res) => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const { email, code } = req.body;

  if (email.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
    return res.status(401).json({ error: 'invalid_credentials' });
  }

  const lock = recentFailures(ip, email);
  if (lock.locked) {
    return res.status(423).json({
      error: 'locked',
      retryAfter: Math.ceil(LOCKOUT_DURATION_MS / 1000),
    });
  }

  const result = verifyOtp(email, code);
  if (!result.ok) {
    recordAttempt(ip, email, false, `otp_${result.reason}`);
    logger.warn(ip, 'otp_verify_failed', { email, reason: result.reason });
    return res.status(401).json({ error: 'invalid_otp', reason: result.reason });
  }

  recordAttempt(ip, email, true, 'otp_ok');
  logger.info(email, 'login_success', { ip });

  const ttl = Number(process.env.JWT_TTL_SECONDS || 3600);
  const token = sign({ sub: email, role: 'admin' }, ttl);
  return res.json({ token, expiresAt: Math.floor(Date.now() / 1000) + ttl });
});

/**
 * POST /auth/logout — stateless; client just discards the token.
 */
router.post('/logout', (req, res) => {
  if (req.admin) logger.info(req.admin.sub, 'logout');
  return res.json({ ok: true });
});

module.exports = router;
