/**
 * utils/email.js — SMTP transport for OTP delivery.
 *
 * Uses nodemailer. If SMTP credentials are not configured, falls back to
 * a console.log so the code is still runnable in dev (the OTP code shows
 * in the server log).
 */
const nodemailer = require('nodemailer');
const logger = require('./logger');

let transport = null;

function getTransport() {
  if (transport) return transport;

  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  if (!user || !pass || pass.startsWith('your-')) {
    // Dev fallback — code is printed to stdout.
    transport = null;
    return null;
  }

  transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: Number(process.env.SMTP_PORT || 465),
    secure: String(process.env.SMTP_SECURE || 'true') === 'true',
    auth: { user, pass },
  });
  return transport;
}

async function sendOtp(to, code) {
  const t = getTransport();
  const subject = 'flkr admin — your one-time code';
  const text =
    `Your flkr admin one-time code is: ${code}\n\n` +
    `It expires in 5 minutes. If you did not request this code, ignore this email.\n`;

  if (!t) {
    // Dev fallback — log to server console (NOT audit_log, to avoid storing the code).
    // eslint-disable-next-line no-console
    console.log(`[email][dev] OTP for ${to}: ${code}`);
    return { dev: true };
  }

  try {
    const info = await t.sendMail({
      from: `"flkr admin" <${process.env.SMTP_USER}>`,
      to,
      subject,
      text,
    });
    logger.info(to, 'otp_sent', { messageId: info.messageId });
    return { messageId: info.messageId };
  } catch (err) {
    logger.error(to, 'otp_send_failed', { error: err.message });
    throw err;
  }
}

module.exports = { sendOtp };
